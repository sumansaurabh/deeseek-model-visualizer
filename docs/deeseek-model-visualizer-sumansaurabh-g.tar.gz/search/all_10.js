var searchData=
[
  ['q_5fa_5flayernorm_0',['q_a_layernorm',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#a37dc6c493e38448e95f12007fe3abd5e',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['q_5fa_5fproj_1',['q_a_proj',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#ae4b3cd0ae7aaca036aa15b0cd108c761',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['q_5fb_5fproj_2',['q_b_proj',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#ab02ecb424285128723576b38da574438',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['q_5fhead_5fdim_3',['q_head_dim',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#a9021aec986b43147703e3f62f78da126',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['q_5flora_5frank_4',['q_lora_rank',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#a28efd11dc4520e5fc75f76b013526805',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['q_5fproj_5',['q_proj',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#ac81d4a3c2486393475ff466c10d401df',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['qk_5fnope_5fhead_5fdim_6',['qk_nope_head_dim',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#af16a31590d1f904d5c3d1ef5ecbd6425',1,'modeling_deepseek.DeepseekV3Attention.qk_nope_head_dim'],['../classmodeling__deepseek_1_1DeepseekV3FlashAttention2.html#a386d163029586f73f88fc97b29742ce9',1,'modeling_deepseek.DeepseekV3FlashAttention2.qk_nope_head_dim']]],
  ['qk_5frope_5fhead_5fdim_7',['qk_rope_head_dim',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#a38ac896a065b4b2eb72d06bd4f04e7bb',1,'modeling_deepseek::DeepseekV3Attention']]]
];
