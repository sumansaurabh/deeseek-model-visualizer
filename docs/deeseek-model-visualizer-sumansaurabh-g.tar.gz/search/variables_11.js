var searchData=
[
  ['scaling_5ffactor_0',['scaling_factor',['../classmodeling__deepseek_1_1DeepseekV3LinearScalingRotaryEmbedding.html#ac154d5c78a36bbd7a676fc51dc4d868c',1,'modeling_deepseek.DeepseekV3LinearScalingRotaryEmbedding.scaling_factor'],['../classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#a7f3bf0b3f2166a8d7a92f3edb75b9ada',1,'modeling_deepseek.DeepseekV3DynamicNTKScalingRotaryEmbedding.scaling_factor'],['../classmodeling__deepseek_1_1DeepseekV3YarnRotaryEmbedding.html#a0450cef3403d2d07eb74172126e825f7',1,'modeling_deepseek.DeepseekV3YarnRotaryEmbedding.scaling_factor']]],
  ['score_1',['score',['../classmodeling__deepseek_1_1DeepseekV3ForSequenceClassification.html#a42e3c0a1e37298d4bf81407969d258f3',1,'modeling_deepseek::DeepseekV3ForSequenceClassification']]],
  ['scoring_5ffunc_2',['scoring_func',['../classmodeling__deepseek_1_1MoEGate.html#a77ec2442dea904601fc1e35f890e1860',1,'modeling_deepseek::MoEGate']]],
  ['self_5fattn_3',['self_attn',['../classmodeling__deepseek_1_1DeepseekV3DecoderLayer.html#af4a351d35571620416cd9097bac15779',1,'modeling_deepseek::DeepseekV3DecoderLayer']]],
  ['seq_5faux_4',['seq_aux',['../classmodeling__deepseek_1_1MoEGate.html#a9a42f726280fd1bc15330b7f3216e95b',1,'modeling_deepseek::MoEGate']]],
  ['shared_5fexperts_5',['shared_experts',['../classmodeling__deepseek_1_1DeepseekV3MoE.html#a90c242857bf845ebf2a97c9e4f7fde86',1,'modeling_deepseek::DeepseekV3MoE']]],
  ['softmax_5fscale_6',['softmax_scale',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#a9c64003a9864d569a2a21ddf17ef125a',1,'modeling_deepseek::DeepseekV3Attention']]],
  ['supports_5fgradient_5fcheckpointing_7',['supports_gradient_checkpointing',['../classmodeling__deepseek_1_1DeepseekV3PreTrainedModel.html#a26ecbd5751fe120046a3ac63de76a119',1,'modeling_deepseek::DeepseekV3PreTrainedModel']]]
];
