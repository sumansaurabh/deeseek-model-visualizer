var searchData=
[
  ['n_5fgroup_0',['n_group',['../classmodeling__deepseek_1_1MoEGate.html#ae44ae50f6e7b07c1ee1d265f3935f57c',1,'modeling_deepseek::MoEGate']]],
  ['n_5frouted_5fexperts_1',['n_routed_experts',['../classmodeling__deepseek_1_1MoEGate.html#a4c5d307e8b47dfd7d6302dcdeb0632c3',1,'modeling_deepseek::MoEGate']]],
  ['norm_2',['norm',['../classmodeling__deepseek_1_1DeepseekV3Model.html#a543831f9b414c380f6ee9c64bb79bd03',1,'modeling_deepseek::DeepseekV3Model']]],
  ['norm_5ftopk_5fprob_3',['norm_topk_prob',['../classmodeling__deepseek_1_1MoEGate.html#a14f1676e0baa38cd3f641c97cb95c694',1,'modeling_deepseek::MoEGate']]],
  ['num_5fexperts_5fper_5ftok_4',['num_experts_per_tok',['../classmodeling__deepseek_1_1DeepseekV3MoE.html#a82fcfa5197c93b130f5ebf788cefd7d7',1,'modeling_deepseek::DeepseekV3MoE']]],
  ['num_5fheads_5',['num_heads',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#a106f42b8983b3692f2bf53fb4ebfafec',1,'modeling_deepseek.DeepseekV3Attention.num_heads'],['../classmodeling__deepseek_1_1DeepseekV3FlashAttention2.html#aac3d7b7bbdfc37a526a6d4dd239a1b10',1,'modeling_deepseek.DeepseekV3FlashAttention2.num_heads']]],
  ['num_5flabels_6',['num_labels',['../classmodeling__deepseek_1_1DeepseekV3ForSequenceClassification.html#a1f6de83af3dd6afb28cbbb210140ef5e',1,'modeling_deepseek::DeepseekV3ForSequenceClassification']]]
];
