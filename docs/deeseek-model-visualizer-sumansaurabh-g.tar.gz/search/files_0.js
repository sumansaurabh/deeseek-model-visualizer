var searchData=
[
  ['modeling_5fdeepseek_2epy_0',['modeling_deepseek.py',['../modeling__deepseek_8py.html',1,'']]]
];
