var searchData=
[
  ['v_5fhead_5fdim_0',['v_head_dim',['../classmodeling__deepseek_1_1DeepseekV3Attention.html#afad36c4bc568470c3e63315c27dbf842',1,'modeling_deepseek.DeepseekV3Attention.v_head_dim'],['../classmodeling__deepseek_1_1DeepseekV3FlashAttention2.html#a04bc6b4d5023bbcd82290a4341ff63db',1,'modeling_deepseek.DeepseekV3FlashAttention2.v_head_dim']]],
  ['variance_5fepsilon_1',['variance_epsilon',['../classmodeling__deepseek_1_1DeepseekV3RMSNorm.html#a0f2b51b768f967bd503eb17b34a55d26',1,'modeling_deepseek::DeepseekV3RMSNorm']]],
  ['vocab_5fsize_2',['vocab_size',['../classmodeling__deepseek_1_1DeepseekV3Model.html#a7706358bbac28fbc7fe2f248721ff686',1,'modeling_deepseek.DeepseekV3Model.vocab_size'],['../classmodeling__deepseek_1_1DeepseekV3ForCausalLM.html#a083b08366f44ab692ef2667058e6fb6f',1,'modeling_deepseek.DeepseekV3ForCausalLM.vocab_size']]]
];
