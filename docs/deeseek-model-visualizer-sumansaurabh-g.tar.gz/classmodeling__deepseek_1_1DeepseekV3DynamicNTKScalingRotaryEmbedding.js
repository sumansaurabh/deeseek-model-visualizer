var classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding =
[
    [ "__init__", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#ab9b04c5d525c2cab59b63c01d831887b", null ],
    [ "_set_cos_sin_cache", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#a7bc816eb10147956ba9463291fe22749", null ],
    [ "dim", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#a6b5502b5e0630e580645660ebf46d942", null ],
    [ "max_position_embeddings", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#a8f9ba629164b9c536d3b6ac860adbf6c", null ],
    [ "max_seq_len_cached", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#a1aa7ce7af86c8ec232856099e8223969", null ],
    [ "scaling_factor", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html#a7f3bf0b3f2166a8d7a92f3edb75b9ada", null ]
];