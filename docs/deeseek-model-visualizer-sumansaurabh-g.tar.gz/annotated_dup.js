var annotated_dup =
[
    [ "modeling_deepseek", "namespacemodeling__deepseek.html", [
      [ "DeepseekV3Attention", "classmodeling__deepseek_1_1DeepseekV3Attention.html", "classmodeling__deepseek_1_1DeepseekV3Attention" ],
      [ "DeepseekV3DecoderLayer", "classmodeling__deepseek_1_1DeepseekV3DecoderLayer.html", "classmodeling__deepseek_1_1DeepseekV3DecoderLayer" ],
      [ "DeepseekV3DynamicNTKScalingRotaryEmbedding", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding.html", "classmodeling__deepseek_1_1DeepseekV3DynamicNTKScalingRotaryEmbedding" ],
      [ "DeepseekV3FlashAttention2", "classmodeling__deepseek_1_1DeepseekV3FlashAttention2.html", "classmodeling__deepseek_1_1DeepseekV3FlashAttention2" ],
      [ "DeepseekV3ForCausalLM", "classmodeling__deepseek_1_1DeepseekV3ForCausalLM.html", "classmodeling__deepseek_1_1DeepseekV3ForCausalLM" ],
      [ "DeepseekV3ForSequenceClassification", "classmodeling__deepseek_1_1DeepseekV3ForSequenceClassification.html", "classmodeling__deepseek_1_1DeepseekV3ForSequenceClassification" ],
      [ "DeepseekV3LinearScalingRotaryEmbedding", "classmodeling__deepseek_1_1DeepseekV3LinearScalingRotaryEmbedding.html", "classmodeling__deepseek_1_1DeepseekV3LinearScalingRotaryEmbedding" ],
      [ "DeepseekV3MLP", "classmodeling__deepseek_1_1DeepseekV3MLP.html", "classmodeling__deepseek_1_1DeepseekV3MLP" ],
      [ "DeepseekV3Model", "classmodeling__deepseek_1_1DeepseekV3Model.html", "classmodeling__deepseek_1_1DeepseekV3Model" ],
      [ "DeepseekV3MoE", "classmodeling__deepseek_1_1DeepseekV3MoE.html", "classmodeling__deepseek_1_1DeepseekV3MoE" ],
      [ "DeepseekV3PreTrainedModel", "classmodeling__deepseek_1_1DeepseekV3PreTrainedModel.html", "classmodeling__deepseek_1_1DeepseekV3PreTrainedModel" ],
      [ "DeepseekV3RMSNorm", "classmodeling__deepseek_1_1DeepseekV3RMSNorm.html", "classmodeling__deepseek_1_1DeepseekV3RMSNorm" ],
      [ "DeepseekV3RotaryEmbedding", "classmodeling__deepseek_1_1DeepseekV3RotaryEmbedding.html", "classmodeling__deepseek_1_1DeepseekV3RotaryEmbedding" ],
      [ "DeepseekV3YarnRotaryEmbedding", "classmodeling__deepseek_1_1DeepseekV3YarnRotaryEmbedding.html", "classmodeling__deepseek_1_1DeepseekV3YarnRotaryEmbedding" ],
      [ "MoEGate", "classmodeling__deepseek_1_1MoEGate.html", "classmodeling__deepseek_1_1MoEGate" ]
    ] ]
];